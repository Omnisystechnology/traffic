"""
Core 4-approach intersection simulation.

This module intentionally mirrors the safety architecture from the TDS:
the "controller" (whoever calls apply_command) can only REQUEST timing
changes. This class enforces minimum/maximum green, mandatory yellow and
all-red clearance, and safe phase switching -- exactly like the certified
signal controller described in TDS Section 19 and Section 21. No caller,
including a buggy or malicious one, can force a conflicting green.
"""
import time
import random
from vehicles import Vehicle, spawn_vehicle, APPROACHES, PCU_WEIGHT

MIN_GREEN = 10.0
MAX_GREEN = 55.0
YELLOW_DUR = 3.0
ALL_RED_DUR = 2.0
DEFAULT_GREEN = 22.0
MAX_PREEMPTION_HOLD = 25.0
STOP_LINE_M = 0.0
SPAWN_M = 80.0
LANE_LENGTH_VISIBLE_M = 95.0   # how far behind the stop line a vehicle is considered "in view"
DEPART_CLEAR_M = -20.0         # vehicle removed once this far past the stop line


class Intersection:
    """A single 4-way signalised junction: N/E/S/W approaches, NS/EW phase groups."""

    def __init__(self, junction_id="jkt-SIM-001", name="Persiaran Sepang x Persiaran APEC (Simulated)"):
        self.junction_id = junction_id
        self.name = name

        self.phase_group = "NS"        # "NS" or "EW" -- which pair currently has right of way
        self.state = "GREEN"           # "GREEN" | "YELLOW" | "ALL_RED"
        self.state_elapsed = 0.0
        self.green_planned_duration = DEFAULT_GREEN

        self.preemption_approach = None    # set when an emergency vehicle needs priority
        self.preemption_elapsed = 0.0

        self.vehicles: list[Vehicle] = []
        self._next_vid = 1
        self.sim_time = 0.0

        self.min_green = MIN_GREEN
        self.max_green = MAX_GREEN

        # spawn tuning: vehicles/second per approach (roughly)
        self.spawn_rate = {"N": 0.28, "E": 0.22, "S": 0.30, "W": 0.20}

        self._audit_log = []
        self._last_command_source = "system_default"

    # ---------------- external control surface (mirrors Modbus/NTCIP request semantics) ----------------

    def apply_command(self, action: str, value: float | None = None, source: str = "controller") -> dict:
        """The ONLY way an external controller can influence signal timing.
        Every request is validated against min/max green and current state
        before being honoured -- this is the safety-validation boundary."""
        accepted = False
        detail = ""

        if action == "set_green_duration":
            if self.state != "GREEN":
                detail = f"rejected: can only set green duration while state is GREEN (currently {self.state})"
            else:
                clamped = max(self.min_green, min(self.max_green, float(value)))
                # never shorten below what has already elapsed -- can't retroactively cut green
                clamped = max(clamped, self.state_elapsed + 0.5)
                self.green_planned_duration = clamped
                accepted = True
                detail = f"green_planned_duration set to {clamped:.1f}s (requested {value}, clamped to [{self.min_green}, {self.max_green}])"

        elif action == "request_switch":
            if self.state == "GREEN" and self.state_elapsed >= self.min_green:
                self.green_planned_duration = self.state_elapsed  # end green now, next tick begins YELLOW
                accepted = True
                detail = "early switch honoured, minimum green already satisfied"
            else:
                accepted = False
                detail = f"rejected: minimum green not yet satisfied ({self.state_elapsed:.1f}s / {self.min_green:.1f}s)"

        elif action == "emergency_preempt":
            approach = value  # here value is the approach letter, e.g. "N"
            self.preemption_approach = approach
            self.preemption_elapsed = 0.0
            accepted = True
            detail = f"preemption armed for approach {approach}"

        elif action == "cancel_preemption":
            self.preemption_approach = None
            accepted = True
            detail = "preemption cancelled"

        else:
            detail = f"unknown or invalid action for current state: {action}"

        self._audit_log.append({
            "ts": round(self.sim_time, 1), "action": action, "value": value,
            "accepted": accepted, "detail": detail, "source": source,
        })
        if len(self._audit_log) > 200:
            self._audit_log.pop(0)
        return {"accepted": accepted, "detail": detail}

    # ---------------- simulation tick ----------------

    def tick(self, dt: float):
        self.sim_time += dt
        self._update_signal_state(dt)
        self._spawn_vehicles(dt)
        self._update_vehicle_physics(dt)
        self._cull_departed_vehicles()

    def _group_of(self, approach: str) -> str:
        return "NS" if approach in ("N", "S") else "EW"

    def _update_signal_state(self, dt):
        self.state_elapsed += dt

        if self.preemption_approach:
            self.preemption_elapsed += dt

        if self.state == "GREEN":
            preempt_needed = (
                self.preemption_approach is not None
                and self._group_of(self.preemption_approach) != self.phase_group
                and self.state_elapsed >= self.min_green
            )
            hit_planned = self.state_elapsed >= self.green_planned_duration
            hit_hard_max = self.state_elapsed >= self.max_green
            if preempt_needed or hit_planned or hit_hard_max:
                self.state = "YELLOW"
                self.state_elapsed = 0.0

        elif self.state == "YELLOW":
            if self.state_elapsed >= YELLOW_DUR:
                self.state = "ALL_RED"
                self.state_elapsed = 0.0

        elif self.state == "ALL_RED":
            if self.state_elapsed >= ALL_RED_DUR:
                # decide next phase group
                if self.preemption_approach and self._group_of(self.preemption_approach) != self.phase_group:
                    self.phase_group = self._group_of(self.preemption_approach)
                else:
                    self.phase_group = "EW" if self.phase_group == "NS" else "NS"
                self.state = "GREEN"
                self.state_elapsed = 0.0
                self.green_planned_duration = DEFAULT_GREEN

                if self.preemption_approach and self.preemption_elapsed > MAX_PREEMPTION_HOLD:
                    self.preemption_approach = None  # safety: preemption cannot hold forever

    def approach_has_row(self, approach: str) -> bool:
        """Right-of-way check used by vehicle physics: only true on solid GREEN
        for that approach's phase group."""
        return self.state == "GREEN" and self._group_of(approach) == self.phase_group

    # ---------------- vehicles ----------------

    def _spawn_vehicles(self, dt):
        for approach in APPROACHES:
            if random.random() < self.spawn_rate[approach] * dt:
                force_emergency = random.random() < 0.004  # rare, independent of normal mix
                v = spawn_vehicle(self._next_vid, approach, force_emergency=force_emergency)
                self._next_vid += 1
                self.vehicles.append(v)

    def _update_vehicle_physics(self, dt):
        by_approach: dict[str, list[Vehicle]] = {a: [] for a in APPROACHES}
        for v in self.vehicles:
            by_approach[v.approach].append(v)

        for approach, vs in by_approach.items():
            vs.sort(key=lambda v: v.position_m)  # closest to stop line first
            row = self.approach_has_row(approach)
            prev_pos = None
            for v in vs:
                gap_ok = True
                if prev_pos is not None:
                    gap_ok = (v.position_m - prev_pos) > (v.length_m + 1.5)

                can_move = gap_ok and (row or v.position_m > STOP_LINE_M + 1.0 and v.crossed)
                if v.position_m <= STOP_LINE_M + 0.3 and not row and not v.crossed:
                    can_move = False  # must hold at stop line on red/yellow/all-red

                target_speed = v.max_speed_mps if can_move else 0.0
                if v.speed_mps < target_speed:
                    v.speed_mps = min(target_speed, v.speed_mps + 3.0 * dt)
                elif v.speed_mps > target_speed:
                    v.speed_mps = max(target_speed, v.speed_mps - 5.0 * dt)

                v.position_m -= v.speed_mps * dt
                if v.position_m <= STOP_LINE_M and not v.crossed:
                    v.crossed = True
                prev_pos = v.position_m

    def _cull_departed_vehicles(self):
        self.vehicles = [v for v in self.vehicles if v.position_m > DEPART_CLEAR_M]

    # ---------------- state readout (ground truth -- used for debug and for the browser view) ----------------

    def lane_state(self, approach: str) -> dict:
        vs = [v for v in self.vehicles if v.approach == approach]
        queued = [v for v in vs if v.is_queued()]
        queue_pcu = sum(v.pcu for v in queued)
        queue_length_m = max([v.position_m for v in queued], default=0.0)
        emergency_present = any(v.vclass == "emergency" and not v.crossed for v in vs)
        return {
            "approach": approach,
            "vehicle_count": len(vs),
            "queued_count": len(queued),
            "queue_pcu": round(queue_pcu, 2),
            "queue_length_m": round(queue_length_m, 1),
            "has_row": self.approach_has_row(approach),
            "emergency_present": emergency_present,
        }

    def countdown_seconds(self, approach: str) -> float:
        """What the physical digital countdown board would show for this approach."""
        group = self._group_of(approach)
        if self.state == "GREEN" and group == self.phase_group:
            return max(0.0, self.green_planned_duration - self.state_elapsed)
        if self.state == "YELLOW" and group == self.phase_group:
            return max(0.0, YELLOW_DUR - self.state_elapsed)
        # red-side countdown: time until it becomes this approach's turn
        if group == self.phase_group:
            # currently in ALL_RED but this group will lose after this cycle
            remaining_this_cycle = max(0.0, ALL_RED_DUR - self.state_elapsed)
            return remaining_this_cycle + self.green_planned_duration + YELLOW_DUR + ALL_RED_DUR
        else:
            if self.state == "GREEN":
                return max(0.0, self.green_planned_duration - self.state_elapsed) + YELLOW_DUR + ALL_RED_DUR
            if self.state == "YELLOW":
                return max(0.0, YELLOW_DUR - self.state_elapsed) + ALL_RED_DUR
            return max(0.0, ALL_RED_DUR - self.state_elapsed)

    def full_state(self) -> dict:
        return {
            "junction_id": self.junction_id,
            "name": self.name,
            "sim_time": round(self.sim_time, 1),
            "phase_group": self.phase_group,
            "state": self.state,
            "state_elapsed": round(self.state_elapsed, 1),
            "green_planned_duration": round(self.green_planned_duration, 1),
            "min_green": self.min_green,
            "max_green": self.max_green,
            "preemption_approach": self.preemption_approach,
            "lanes": {a: self.lane_state(a) for a in APPROACHES},
            "countdowns": {a: round(self.countdown_seconds(a), 1) for a in APPROACHES},
            "vehicle_total": len(self.vehicles),
            "recent_audit": self._audit_log[-10:],
        }
