"""
Entrypoint for the simulator container.
Run with: uvicorn main:app --host 0.0.0.0 --port 8000
(This file just re-exports the FastAPI app from api.py so `uvicorn main:app` works.)
"""
from api import app  # noqa: F401
