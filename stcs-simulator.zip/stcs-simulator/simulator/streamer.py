"""
Pushes raw RGB frames into an ffmpeg subprocess that publishes them as an
RTSP stream. This is what makes the simulator look like a real IP camera
to Frigate (or any other NVR) -- Frigate just points at the RTSP URL and
has no idea the "camera" is a simulation.
"""
import logging
import subprocess

log = logging.getLogger("sim.streamer")


class RtspPusher:
    def __init__(self, rtsp_url: str, width: int, height: int, fps: int = 15):
        self.rtsp_url = rtsp_url
        self.width = width
        self.height = height
        self.fps = fps
        self.proc = None
        self._start()

    def _start(self):
        cmd = [
            "ffmpeg",
            "-loglevel", "error",
            "-f", "rawvideo",
            "-pixel_format", "rgb24",
            "-video_size", f"{self.width}x{self.height}",
            "-framerate", str(self.fps),
            "-i", "-",
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-tune", "zerolatency",
            "-pix_fmt", "yuv420p",
            "-f", "rtsp",
            "-rtsp_transport", "tcp",
            self.rtsp_url,
        ]
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            log.info("ffmpeg RTSP pusher started -> %s", self.rtsp_url)
        except FileNotFoundError:
            log.error("ffmpeg not found; RTSP push disabled")
            self.proc = None

    def push_frame(self, rgb_bytes: bytes):
        if self.proc is None or self.proc.stdin is None:
            return
        try:
            self.proc.stdin.write(rgb_bytes)
        except (BrokenPipeError, OSError):
            log.warning("ffmpeg pipe broke, restarting pusher")
            self._start()
