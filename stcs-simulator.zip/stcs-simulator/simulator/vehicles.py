"""
Vehicle model for the STCS intersection simulator.

Vehicle classes and PCU (Passenger Car Unit) weights match TDS Section 14
(Traffic Density Calculations), deliberately including a heavy motorcycle
share to reflect Malaysian urban traffic mix.
"""
import random
from dataclasses import dataclass, field

# PCU weights: TDS Section 14 table
PCU_WEIGHT = {
    "motorcycle": 0.25,
    "car": 1.0,
    "van": 1.25,
    "bus": 2.5,
    "truck": 2.75,
    "emergency": 1.0,  # PCU weight for space; priority handled separately, not via PCU
}

# Relative spawn probability -- motorcycle-heavy, matching Malaysian urban mix
SPAWN_WEIGHTS = {
    "motorcycle": 0.42,
    "car": 0.40,
    "van": 0.08,
    "bus": 0.03,
    "truck": 0.06,
    "emergency": 0.01,
}

# Visual + physical size per class (length, width in simulation metres)
VEHICLE_SIZE = {
    "motorcycle": (1.9, 0.7),
    "car": (4.2, 1.8),
    "van": (4.8, 1.9),
    "bus": (10.5, 2.5),
    "truck": (8.5, 2.4),
    "emergency": (5.2, 2.0),
}

VEHICLE_COLOR = {
    "motorcycle": (240, 200, 60),
    "car": (90, 160, 240),
    "van": (150, 150, 170),
    "bus": (230, 130, 60),
    "truck": (180, 90, 90),
    "emergency": (240, 60, 70),
}

APPROACHES = ["N", "E", "S", "W"]  # vehicle travels TOWARD the junction from this compass direction


def pick_vehicle_class(force_emergency: bool = False) -> str:
    if force_emergency:
        return "emergency"
    classes = list(SPAWN_WEIGHTS.keys())
    weights = list(SPAWN_WEIGHTS.values())
    return random.choices(classes, weights=weights, k=1)[0]


@dataclass
class Vehicle:
    vid: int
    vclass: str
    approach: str          # "N" | "E" | "S" | "W" -- which approach lane this vehicle is queued on
    position_m: float      # distance from the stop line, in metres (positive = behind the line, approaching)
    speed_mps: float = 0.0
    max_speed_mps: float = 12.0     # ~43 km/h approach speed
    length_m: float = 4.2
    width_m: float = 1.8
    color: tuple = (90, 160, 240)
    crossed: bool = False
    stopped_since: float = 0.0      # simulation time this vehicle has been stationary (queue dwell)
    siren_on: bool = False

    @property
    def pcu(self) -> float:
        return PCU_WEIGHT[self.vclass]

    def is_queued(self, speed_threshold=0.6) -> bool:
        return (not self.crossed) and self.speed_mps < speed_threshold and self.position_m > 0.5


def spawn_vehicle(vid: int, approach: str, force_emergency: bool = False) -> Vehicle:
    vclass = pick_vehicle_class(force_emergency)
    length, width = VEHICLE_SIZE[vclass]
    v = Vehicle(
        vid=vid,
        vclass=vclass,
        approach=approach,
        position_m=80.0 + random.uniform(-3, 3),   # spawn 80m back from the stop line
        speed_mps=random.uniform(8, 11),
        max_speed_mps=random.uniform(10, 13),
        length_m=length,
        width_m=width,
        color=VEHICLE_COLOR[vclass],
        siren_on=(vclass == "emergency"),
    )
    return v
