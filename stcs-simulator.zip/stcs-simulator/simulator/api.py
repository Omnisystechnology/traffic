"""
FastAPI service wrapping the Intersection simulation.

Endpoints:
  GET  /state        -- ground-truth JSON state (useful for testing without Frigate at all)
  POST /command       -- the ONLY way to influence signal timing (mirrors Modbus/NTCIP request semantics)
  GET  /health
  GET  /mjpeg         -- live MJPEG stream, viewable directly in any browser at /mjpeg
  GET  /frame.jpg     -- single current frame as a JPEG (handy for quick checks / curl)

A background thread runs the simulation at a fixed real-time tick rate and
also pushes raw frames to an RTSP relay (see streamer.py) so Frigate can
consume this exactly like a real camera.
"""
import io
import os
import threading
import time
import logging

from fastapi import FastAPI, Body
from fastapi.responses import StreamingResponse, JSONResponse
import pygame

from intersection import Intersection
from renderer import Renderer
from streamer import RtspPusher

logging.basicConfig(level=logging.INFO, format="%(asctime)s [sim] %(message)s")
log = logging.getLogger("sim")

TICK_HZ = 15.0
RTSP_URL = os.environ.get("RTSP_PUSH_URL", "")  # e.g. rtsp://mediamtx:8554/stcs-sim ; empty = disabled

app = FastAPI(title="STCS Intersection Simulator")

isec = Intersection()
renderer = Renderer()
_state_lock = threading.Lock()
_latest_jpeg = b""
_frame_clients_seq = 0

pusher = RtspPusher(RTSP_URL, renderer.surface.get_width(), renderer.surface.get_height()) if RTSP_URL else None


def _sim_loop():
    global _latest_jpeg, _frame_clients_seq
    dt = 1.0 / TICK_HZ
    next_t = time.time()
    while True:
        with _state_lock:
            isec.tick(dt)
            state = isec.full_state()
            renderer.render(state, isec.vehicles)
            jpeg_bytes = pygame_surface_to_jpeg(renderer.surface)
            _latest_jpeg = jpeg_bytes
            _frame_clients_seq += 1
            if pusher:
                pusher.push_frame(renderer.to_rgb_bytes())
        next_t += dt
        sleep_for = next_t - time.time()
        if sleep_for > 0:
            time.sleep(sleep_for)
        else:
            next_t = time.time()


def pygame_surface_to_jpeg(surface) -> bytes:
    raw = pygame.image.tostring(surface, "RGB")
    from PIL import Image
    img = Image.frombytes("RGB", surface.get_size(), raw)
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=80)
    return buf.getvalue()


@app.on_event("startup")
def start_background_loop():
    t = threading.Thread(target=_sim_loop, daemon=True)
    t.start()
    log.info("simulation loop started at %.1f Hz, RTSP push %s", TICK_HZ, "enabled -> " + RTSP_URL if pusher else "disabled")


@app.get("/health")
def health():
    return {"status": "ok", "junction_id": isec.junction_id}


@app.get("/state")
def get_state():
    with _state_lock:
        return JSONResponse(isec.full_state())


@app.post("/command")
def post_command(payload: dict = Body(...)):
    """
    Body: {"action": "set_green_duration" | "request_switch" | "emergency_preempt" | "cancel_preemption",
           "value": <number or approach letter, action-dependent>,
           "source": "controller" (optional, for audit log)}
    """
    action = payload.get("action")
    value = payload.get("value")
    source = payload.get("source", "controller")
    with _state_lock:
        result = isec.apply_command(action, value, source=source)
    return result


@app.get("/frame.jpg")
def get_frame():
    with _state_lock:
        data = _latest_jpeg
    return StreamingResponse(io.BytesIO(data), media_type="image/jpeg")


def _mjpeg_generator():
    last_seq = -1
    while True:
        with _state_lock:
            seq = _frame_clients_seq
            data = _latest_jpeg
        if seq != last_seq and data:
            last_seq = seq
            yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + data + b"\r\n")
        time.sleep(1.0 / TICK_HZ)


@app.get("/mjpeg")
def mjpeg():
    return StreamingResponse(_mjpeg_generator(), media_type="multipart/x-mixed-replace; boundary=frame")
