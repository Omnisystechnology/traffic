"""
Top-down 2D renderer for the intersection. Runs headless (SDL 'dummy'
video driver) so it can produce video frames inside a container with no
display and no GPU -- this is what gets streamed out to Frigate.
"""
import os
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
import pygame

from vehicles import APPROACHES

WIDTH, HEIGHT = 1280, 800
CENTER = (WIDTH // 2, HEIGHT // 2)
ROAD_HALF_W = 58
SCALE = 7.0  # pixels per metre

BG = (28, 32, 40)
ROAD = (54, 58, 68)
LANE_LINE = (110, 115, 125)
CURB = (80, 84, 92)
SIGNAL_POST = (40, 43, 50)

LAMP_OFF = (40, 20, 20)
LAMP_RED = (235, 60, 65)
LAMP_YELLOW = (240, 190, 60)
LAMP_GREEN = (60, 210, 120)

BOARD_BG = (10, 12, 16)
BOARD_DIGIT_NORMAL = (60, 220, 130)
BOARD_DIGIT_LOW = (240, 190, 60)
BOARD_DIGIT_CRIT = (240, 70, 75)

POSTS = {
    "N": (CENTER[0] - ROAD_HALF_W - 34, CENTER[1] - ROAD_HALF_W - 34),
    "S": (CENTER[0] + ROAD_HALF_W + 34, CENTER[1] + ROAD_HALF_W + 34),
    "E": (CENTER[0] + ROAD_HALF_W + 34, CENTER[1] - ROAD_HALF_W - 34),
    "W": (CENTER[0] - ROAD_HALF_W - 34, CENTER[1] + ROAD_HALF_W + 34),
}

LANE_OFFSET = {  # keeps each approach's vehicles on their own side of the road (left-hand traffic)
    "N": -18, "S": 18, "E": -18, "W": 18,
}


class Renderer:
    def __init__(self):
        pygame.init()
        pygame.display.set_mode((1, 1))  # required by SDL dummy driver, not actually shown
        self.surface = pygame.Surface((WIDTH, HEIGHT))
        self.font_board = pygame.font.SysFont("couriernew,monospace", 30, bold=True)
        self.font_label = pygame.font.SysFont("arial,sans-serif", 15, bold=True)
        self.font_hud = pygame.font.SysFont("arial,sans-serif", 16)
        self.font_hud_b = pygame.font.SysFont("arial,sans-serif", 16, bold=True)

    # ---------------- helpers ----------------

    def _vehicle_screen_pos(self, v):
        off = LANE_OFFSET[v.approach]
        if v.approach == "N":
            x = CENTER[0] + off
            y = CENTER[1] - ROAD_HALF_W - v.position_m * SCALE
        elif v.approach == "S":
            x = CENTER[0] + off
            y = CENTER[1] + ROAD_HALF_W + v.position_m * SCALE
        elif v.approach == "E":
            x = CENTER[0] + ROAD_HALF_W + v.position_m * SCALE
            y = CENTER[1] + off
        else:  # W
            x = CENTER[0] - ROAD_HALF_W - v.position_m * SCALE
            y = CENTER[1] + off
        return x, y

    def _draw_roads(self):
        self.surface.fill(BG)
        # vertical road (N-S)
        pygame.draw.rect(self.surface, ROAD, (CENTER[0] - ROAD_HALF_W, 0, ROAD_HALF_W * 2, HEIGHT))
        # horizontal road (E-W)
        pygame.draw.rect(self.surface, ROAD, (0, CENTER[1] - ROAD_HALF_W, WIDTH, ROAD_HALF_W * 2))
        # lane dividers (dashed)
        for y in range(0, HEIGHT, 26):
            if abs(y - CENTER[1]) > ROAD_HALF_W:
                pygame.draw.rect(self.surface, LANE_LINE, (CENTER[0] - 1, y, 2, 14))
        for x in range(0, WIDTH, 26):
            if abs(x - CENTER[0]) > ROAD_HALF_W:
                pygame.draw.rect(self.surface, LANE_LINE, (x, CENTER[1] - 1, 14, 2))
        # stop lines
        pygame.draw.rect(self.surface, (230, 230, 230), (CENTER[0] - ROAD_HALF_W, CENTER[1] - ROAD_HALF_W - 4, ROAD_HALF_W, 4))
        pygame.draw.rect(self.surface, (230, 230, 230), (CENTER[0], CENTER[1] + ROAD_HALF_W, ROAD_HALF_W, 4))
        pygame.draw.rect(self.surface, (230, 230, 230), (CENTER[0] + ROAD_HALF_W, CENTER[1] - ROAD_HALF_W, 4, ROAD_HALF_W))
        pygame.draw.rect(self.surface, (230, 230, 230), (CENTER[0] - ROAD_HALF_W - 4, CENTER[1], 4, ROAD_HALF_W))
        # intersection box
        pygame.draw.rect(self.surface, (46, 50, 59), (CENTER[0] - ROAD_HALF_W, CENTER[1] - ROAD_HALF_W, ROAD_HALF_W * 2, ROAD_HALF_W * 2))

    def _draw_vehicle(self, v):
        x, y = self._vehicle_screen_pos(v)
        length_px = max(6, v.length_m * SCALE * 0.6)
        width_px = max(5, v.width_m * SCALE * 0.6)
        if v.approach in ("N", "S"):
            rect = pygame.Rect(0, 0, width_px, length_px)
        else:
            rect = pygame.Rect(0, 0, length_px, width_px)
        rect.center = (x, y)
        if -40 < x < WIDTH + 40 and -40 < y < HEIGHT + 40:
            pygame.draw.rect(self.surface, v.color, rect, border_radius=2)
            if v.siren_on:
                blink = int(pygame.time.get_ticks() / 150) % 2 == 0
                c = (255, 60, 60) if blink else (60, 90, 255)
                pygame.draw.rect(self.surface, c, rect.inflate(4, 4), width=2, border_radius=3)

    def _draw_signal_head(self, approach, state, active_group_here):
        px, py = POSTS[approach]
        pygame.draw.rect(self.surface, SIGNAL_POST, (px - 14, py - 44, 28, 60), border_radius=4)
        red_on = not active_group_here or state in ("ALL_RED",) or (active_group_here and state == "ALL_RED")
        yellow_on = active_group_here and state == "YELLOW"
        green_on = active_group_here and state == "GREEN"
        red_on = not (yellow_on or green_on)
        for i, (on, col) in enumerate([(red_on, LAMP_RED), (yellow_on, LAMP_YELLOW), (green_on, LAMP_GREEN)]):
            cy = py - 34 + i * 16
            pygame.draw.circle(self.surface, col if on else LAMP_OFF, (px, cy), 6)
            if on:
                s = pygame.Surface((26, 26), pygame.SRCALPHA)
                pygame.draw.circle(s, (*col, 70), (13, 13), 13)
                self.surface.blit(s, (px - 13, cy - 13))

    def _draw_countdown_board(self, approach, seconds):
        px, py = POSTS[approach]
        bx, by = px - 26, py + 20
        board = pygame.Rect(bx, by, 52, 28)
        pygame.draw.rect(self.surface, BOARD_BG, board, border_radius=3)
        pygame.draw.rect(self.surface, (70, 74, 82), board, width=1, border_radius=3)
        secs = max(0, int(round(seconds)))
        color = BOARD_DIGIT_NORMAL if secs > 8 else (BOARD_DIGIT_LOW if secs > 3 else BOARD_DIGIT_CRIT)
        txt = self.font_board.render(f"{secs:02d}", True, color)
        self.surface.blit(txt, txt.get_rect(center=board.center))
        lbl = self.font_label.render(approach, True, (200, 205, 212))
        self.surface.blit(lbl, lbl.get_rect(midtop=(board.centerx, board.bottom + 2)))

    def _draw_hud(self, state: dict):
        lines = [
            (f"STCS SIMULATOR  \u2014  {state['name']}", self.font_hud_b, (230, 235, 240)),
            (f"junction: {state['junction_id']}   sim_t: {state['sim_time']:.1f}s   phase: {state['phase_group']} / {state['state']}", self.font_hud, (170, 178, 190)),
        ]
        y = 14
        for text, font, color in lines:
            surf = font.render(text, True, color)
            self.surface.blit(surf, (16, y))
            y += 20
        if state.get("preemption_approach"):
            warn = self.font_hud_b.render(f"EMERGENCY PREEMPTION ACTIVE: approach {state['preemption_approach']}", True, (240, 90, 90))
            self.surface.blit(warn, (16, y + 4))

    # ---------------- public ----------------

    def render(self, state: dict, vehicles: list) -> pygame.Surface:
        self._draw_roads()
        for v in vehicles:
            self._draw_vehicle(v)
        for approach in APPROACHES:
            active_here = state["state"] == "GREEN" and self._group_of(approach) == state["phase_group"]
            active_here = active_here or (state["state"] == "YELLOW" and self._group_of(approach) == state["phase_group"])
            self._draw_signal_head(approach, state["state"], self._group_of(approach) == state["phase_group"])
            self._draw_countdown_board(approach, state["countdowns"][approach])
        self._draw_hud(state)
        return self.surface

    @staticmethod
    def _group_of(approach):
        return "NS" if approach in ("N", "S") else "EW"

    def to_rgb_bytes(self) -> bytes:
        return pygame.image.tostring(self.surface, "RGB")

    def save_png(self, path: str):
        pygame.image.save(self.surface, path)
