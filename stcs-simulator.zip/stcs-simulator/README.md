# STCS Intersection Simulator

A digital twin of a single 4-approach signalised junction, built to
validate the Smart Traffic Control System's control loop end-to-end
(camera -> detection -> max-pressure decision -> safety-validated
signal change) before any of it touches real hardware in Cyberjaya.

This is not a toy animation. The signal state machine enforces the exact
same minimum/maximum green and clearance-interval rules as TDS Section 19,
and no external caller -- including the control algorithm itself -- can
force a conflicting green. That validation happened during build: see
`docs/FRIGATE_INTEGRATION.md` and the commit history in this project for
the safety-rejection behaviour actually being exercised.

## What's in the box

| Service | Role |
|---|---|
| `simulator` | Renders the 4-approach intersection (roads, vehicles, signal heads, digital countdown boards), runs vehicle physics, and enforces signal safety rules. Exposes a browser-viewable stream and a control API. |
| `mediamtx` | Lightweight RTSP relay -- the simulator publishes here, Frigate subscribes here. |
| `frigate` | Real, unmodified Frigate NVR, watching the simulator's video exactly as it would watch a real camera. |
| `mosquitto` | MQTT broker, same role it plays in the full STCS architecture. |
| `controller` | Runs the max-pressure algorithm (identical logic to TDS Section 13.2) and sends signal-timing requests back to the simulator. |

## Quick start

```bash
docker compose up --build
```

Then open:
- **`http://localhost:8000/mjpeg`** -- watch the simulated intersection live in any browser, no Frigate required
- **`http://localhost:8000/state`** -- ground-truth JSON state (queues, phase, countdowns)
- **`http://localhost:5000`** -- Frigate's own web UI, to see what it's actually detecting
- **`http://localhost:8000/frame.jpg`** -- a single current frame, handy for a quick `curl` check

The controller starts in `DETECTION_SOURCE=ground_truth` mode by default,
so the full control loop is demonstrable immediately without waiting on
Frigate detection tuning. See `docs/FRIGATE_INTEGRATION.md` for how to
switch to real Frigate-driven detection once it's validated.

## What's simulated, matching the TDS

- **4 approaches (N/E/S/W)**, each with its own signal head and digital
  countdown board (TDS Section 12, the requested "each road has their own
  traffic lights with a timer digital board").
- **Motorcycle-heavy Malaysian vehicle mix** with PCU weighting exactly per
  TDS Section 14 (motorcycle 0.25, car 1.0, van 1.25, bus 2.5, truck 2.75).
- **Max-pressure adaptive control** (TDS Section 13.2), computing which
  phase group should have the green based on live queue pressure.
- **Minimum/maximum green enforcement and mandatory yellow/all-red
  clearance** (TDS Section 16, 19) -- enforced by the simulator itself,
  standing in for the certified controller. Every control request is
  validated before being honoured; requests before minimum green is
  satisfied are rejected, not silently ignored.
- **Emergency vehicle preemption** (TDS Section 17) -- occasional emergency
  vehicles spawn automatically; `/command` with `emergency_preempt` requests
  priority, capped by a hard maximum hold time so it can never lock the
  junction indefinitely.
- **Full audit trail** of every command request and whether it was accepted
  or rejected, available in `/state`.

## What's intentionally simplified (be upfront about this with anyone reviewing it)

- **Single lane per approach**, not multi-lane with turn movements.
- **Queue estimation is a straightforward stopped/PCU proxy**, not the full
  homography-calibrated, speed-history-based method in TDS Section 15 --
  that's the natural next refinement once this pipeline is validated end to end.
- **No downstream/corridor coordination** -- this is one isolated junction,
  not the green-wave corridor logic in TDS Section 13.3. Extending to
  multiple simulated junctions is straightforward (multiple `simulator`
  instances + one `controller` reading all of them) but not built here.
- **Pedestrian crossing logic (TDS Section 18) is not implemented.**

## Project layout

```
stcs-simulator/
├── docker-compose.yml
├── simulator/          # the intersection: physics, rendering, safety-validated control API
├── controller/         # max-pressure algorithm + Frigate/ground-truth detection adapter
├── mosquitto/          # MQTT broker config
├── mediamtx/           # RTSP relay config
├── frigate/            # Frigate NVR config, pointed at the simulator's RTSP feed
└── docs/
    └── FRIGATE_INTEGRATION.md   # read this before touching detection tuning
```

## Running the simulator standalone, without Docker

Useful for fast iteration on the physics/rendering:

```bash
cd simulator
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

RTSP push is automatically disabled if `RTSP_PUSH_URL` isn't set, so this
works with zero other services running -- you'll just have `/mjpeg` and
`/state`, no Frigate feed.
