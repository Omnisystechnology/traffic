# Frigate Integration Guide

This is for whoever (your technical officer) is wiring real detection into
this simulator, or later swapping the simulator for a real camera.

## Why Frigate, and how this is wired

Frigate is a self-hostable NVR with built-in object detection. It was
chosen specifically to avoid the AGPL-3.0 licensing exposure that comes
with shipping a commercial product built on stock Ultralytics YOLOv8/v11
(see the TDS's AI Model Selection section) -- Frigate is a clean,
self-hosted alternative for the pilot stage, and a custom/fine-tuned
detector can be attached to it later without re-architecting anything.

The simulator does not know Frigate exists. It just renders frames and
pushes them out over RTSP (`simulator -> ffmpeg -> mediamtx -> frigate`).
Frigate does not know the video is simulated. It just watches an RTSP URL
and publishes JSON detection events to MQTT, exactly like it would for a
real camera. This is the whole point of the design: **swapping the
simulator for a real ESP32/IP camera later is a one-line config change
(the RTSP path in `frigate/config.yml`), not a rewrite.**

## Two ways to run the control loop

Set via the `DETECTION_SOURCE` environment variable on the `controller` service:

| Value | What it does | When to use it |
|---|---|---|
| `ground_truth` (default) | Controller reads the simulator's own internal state directly via `/state` | Validating the control algorithm and the whole pipeline works, independent of detector quality. **Start here.** |
| `frigate_mqtt` | Controller uses ONLY what Frigate detected, via `frigate/events` on MQTT | The real integration path -- switch to this once you've confirmed Frigate is reliably seeing vehicles in the simulated video |

Do not skip straight to `frigate_mqtt` and assume it works. See the next section.

## Honest expectations: will Frigate actually detect the simulated vehicles?

Not guaranteed out of the box, and you should verify it before trusting it.
Frigate's default bundled model is trained on real-world camera footage.
The simulator renders vehicles as simple flat-colour rectangles from a
top-down angle. That's a real domain gap. Concretely, expect to do some or
all of the following:

1. **Check the Frigate web UI first** (`http://localhost:5000` once the
   stack is running) -- watch the live feed and see whether bounding boxes
   are appearing on the simulated vehicles at all before touching any code.
2. **Lower `min_score` / `threshold`** in `frigate/config.yml` if detections
   are inconsistent (already set lower for `motorcycle` specifically, since
   small objects are the hardest case -- see TDS Section 27).
3. **Make the simulator's vehicles more detector-friendly** if step 1 shows
   nothing at all -- e.g. increase contrast against the road, add a simple
   outline/shadow in `simulator/renderer.py`'s `_draw_vehicle`, or increase
   `detect.fps` in the Frigate camera config for more sampling opportunities.
4. **Attach a custom/fine-tuned model** as the real fix, once you're past
   pure pipeline validation -- Frigate supports custom ONNX/TensorRT
   detectors. This is also the eventual production path per TDS Section 8.5
   (a Malaysia-specific fine-tuned model), so time spent here isn't wasted
   even though the simulator is a stand-in.

## Adding emergency vehicle detection

Frigate's default model has no "emergency vehicle" class. `controller/frigate_adapter.py`
has a clear extension point (`FRIGATE_LABEL_TO_VCLASS`) where you can:
- map a custom-trained class to `"emergency"`, or
- subscribe to a second, separate topic fed by an acoustic siren classifier
  (per TDS Section 8.3's dual-modality design) and fuse it with Frigate's
  visual detections in `frigate_adapter.py`.

The simulator already spawns emergency vehicles occasionally (visually
distinct with a flashing outline) and the `/command` API already supports
`emergency_preempt` -- the missing piece is purely the detection side.

## Recalibrating the approach zones

`controller/frigate_adapter.py`'s `APPROACH_ZONES_PX` and `frigate/config.yml`'s
`zones:` block both define the same four rectangles and **must be kept in
sync** if you change the simulator's camera framing (`simulator/renderer.py`'s
`CENTER`, `ROAD_HALF_W`, `LANE_OFFSET`). This mirrors the real-world
per-camera homography calibration described in TDS Section 7.1 and Section 39.3
-- in production this is a one-time physical installation step per camera,
not something you'd expect to change often.

## Useful commands while developing

```bash
# Watch raw Frigate MQTT events directly (bypasses the controller entirely)
docker compose exec mosquitto mosquitto_sub -t "frigate/events" -v

# Watch the simulator's own ground-truth state for comparison
watch -n1 "curl -s http://localhost:8000/state | python3 -m json.tool"

# Tail the controller's decision log
docker compose logs -f controller
```
