"""
Max-pressure adaptive control algorithm.
Identical logic to TDS Section 13.2 / Section 39.1 -- kept as a standalone,
independently testable module so it is the SAME code whether it runs here
against simulated/Frigate-derived data or later against real edge hardware.
"""
from dataclasses import dataclass

PCU_WEIGHT = {
    "motorcycle": 0.25, "car": 1.0, "van": 1.25, "bus": 2.5, "truck": 2.75, "emergency": 1.0,
}


@dataclass
class LaneState:
    approach: str
    queue_pcu: float


def group_pressure(group: str, lane_states: dict[str, LaneState]) -> float:
    """Pressure for a phase group = sum of queue PCU on its approaches.
    (Downstream subtraction omitted for a single isolated junction --
    add it back in when chaining junctions along a corridor.)"""
    members = ("N", "S") if group == "NS" else ("E", "W")
    return sum(lane_states[a].queue_pcu for a in members if a in lane_states)


def next_phase_recommendation(lane_states: dict[str, LaneState], current_group: str,
                               switch_margin: float = 1.5) -> dict:
    """Returns a recommendation dict: which group SHOULD have the green,
    and by how much pressure it currently leads. Does not enforce min/max
    green itself -- that enforcement lives in the Intersection state
    machine (the 'certified controller' stand-in), exactly mirroring how
    the real edge algorithm only ever RECOMMENDS to the certified controller."""
    ns_pressure = group_pressure("NS", lane_states)
    ew_pressure = group_pressure("EW", lane_states)
    leader = "NS" if ns_pressure >= ew_pressure else "EW"
    margin = abs(ns_pressure - ew_pressure)
    should_switch = (leader != current_group) and (margin > switch_margin)
    return {
        "ns_pressure": round(ns_pressure, 2),
        "ew_pressure": round(ew_pressure, 2),
        "recommended_group": leader,
        "pressure_margin": round(margin, 2),
        "should_switch": should_switch,
    }


def recommended_green_extension(lane_states: dict[str, LaneState], active_group: str,
                                 base: float = 18.0, per_pcu: float = 1.1,
                                 min_green: float = 10.0, max_green: float = 55.0) -> float:
    """A simple, explainable extension rule: more queued PCU on the active
    group's approaches -> longer green, clamped to min/max. Deliberately
    not a black box -- an engineer can explain any number this produces."""
    pressure = group_pressure(active_group, lane_states)
    duration = base + per_pcu * pressure
    return max(min_green, min(max_green, duration))
