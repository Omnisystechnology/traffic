"""
Frigate integration adapter.

Frigate publishes JSON detection events to MQTT topic '<FRIGATE_TOPIC_PREFIX>/events'
every time a tracked object is created, updated, or ends. Each event's
after.box is [x1, y1, x2, y2] in the camera's detect-resolution pixel space.

This module has NO dependency on how the video was produced -- it works
identically whether the camera is this simulator or a real ESP32/IP camera
in the field. That is the whole point: swapping the simulator for a real
Frigate + real camera later is a config change, not a code change.

HONEST NOTE FOR THE TECHNICAL OFFICER:
Frigate's default bundled model is trained on real-world video. Whether it
reliably classifies simplified 2D simulation graphics as "car" / "motorcycle"
/ etc. is NOT guaranteed out of the box and should be validated against
your actual rendered stream -- see docs/FRIGATE_INTEGRATION.md for how to
tune this (lower min_score, adjust the simulator's vehicle rendering to be
more detector-friendly, or train/attach a custom model). A ground-truth
fallback mode (reading the simulator's own /state endpoint) is included
in controller/main.py specifically so the control loop and dashboard can
be demonstrated and validated independently of detector tuning.
"""
import json
import logging
import time
from dataclasses import dataclass, field

log = logging.getLogger("controller.frigate_adapter")

# Zone rectangles in the simulator's 1280x800 frame, one per approach.
# MUST be recalibrated (see TDS Section 7.1) if the camera framing changes,
# or replaced with Frigate's native polygon "zones" config for production.
APPROACH_ZONES_PX = {
    "N": (600, 0, 644, 342),
    "S": (622, 458, 676, 800),
    "E": (698, 364, 1280, 400),
    "W": (0, 400, 582, 436),
}

FRIGATE_LABEL_TO_VCLASS = {
    "car": "car",
    "motorcycle": "motorcycle",
    "bus": "bus",
    "truck": "truck",
    # Frigate's default COCO-based model has no "emergency vehicle" class.
    # Extension point: attach a custom/fine-tuned model (TDS Section 8.3) or
    # a separate acoustic siren classifier, and publish to a distinct topic
    # this adapter also subscribes to -- see docs/FRIGATE_INTEGRATION.md.
}

PCU_WEIGHT = {"motorcycle": 0.25, "car": 1.0, "van": 1.25, "bus": 2.5, "truck": 2.75, "emergency": 1.0}


def _centroid(box):
    x1, y1, x2, y2 = box
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


def classify_zone(box) -> str | None:
    cx, cy = _centroid(box)
    for approach, (x1, y1, x2, y2) in APPROACH_ZONES_PX.items():
        if x1 <= cx <= x2 and y1 <= cy <= y2:
            return approach
    return None


@dataclass
class TrackedObject:
    obj_id: str
    label: str
    box: tuple
    last_seen: float = field(default_factory=time.time)


class FrigateDetectionStore:
    """Maintains the set of currently-active tracked objects, built purely
    from frigate/events MQTT messages. Stale objects (no update for
    STALE_AFTER_S) are dropped so a vehicle that left frame doesn't linger
    forever in the queue estimate."""

    STALE_AFTER_S = 3.0

    def __init__(self):
        self._objects: dict[str, TrackedObject] = {}

    def handle_event(self, payload: bytes):
        try:
            msg = json.loads(payload)
        except json.JSONDecodeError:
            log.warning("bad JSON on frigate/events, ignoring")
            return

        ev_type = msg.get("type")
        after = msg.get("after") or {}
        obj_id = after.get("id")
        label = after.get("label")
        box = after.get("box")

        if not obj_id:
            return

        if ev_type == "end":
            self._objects.pop(obj_id, None)
            return

        if label not in FRIGATE_LABEL_TO_VCLASS or not box:
            return  # not a vehicle class we track (e.g. "person"), or malformed

        self._objects[obj_id] = TrackedObject(obj_id=obj_id, label=label, box=tuple(box), last_seen=time.time())

    def _prune_stale(self):
        now = time.time()
        stale = [k for k, v in self._objects.items() if now - v.last_seen > self.STALE_AFTER_S]
        for k in stale:
            self._objects.pop(k, None)

    def lane_states(self) -> dict:
        """Returns {approach: {"queue_pcu": float, "count": int}} derived
        purely from currently-active Frigate-tracked objects. This is a
        deliberately simple proxy (object count weighted by PCU inside each
        zone) -- TDS Section 15's speed-based stopped/queued distinction is
        the natural next refinement once track history is wired through."""
        self._prune_stale()
        result = {a: {"queue_pcu": 0.0, "count": 0} for a in APPROACH_ZONES_PX}
        for obj in self._objects.values():
            approach = classify_zone(obj.box)
            if approach is None:
                continue
            vclass = FRIGATE_LABEL_TO_VCLASS[obj.label]
            result[approach]["queue_pcu"] += PCU_WEIGHT[vclass]
            result[approach]["count"] += 1
        for a in result:
            result[a]["queue_pcu"] = round(result[a]["queue_pcu"], 2)
        return result
