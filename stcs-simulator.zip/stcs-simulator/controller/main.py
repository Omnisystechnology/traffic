"""
Controller service entrypoint.

Runs the same control loop shape as the real edge unit in the TDS:
  detections -> lane density/queue -> max-pressure decision -> request to
  the certified controller (here: the simulator's /command endpoint, which
  enforces min/max green exactly like TDS Section 19/21).

DETECTION_SOURCE env var:
  "ground_truth" (default) -- reads the simulator's own /state endpoint.
      Use this to validate/demo the control loop independent of detector
      tuning. This is what a from-scratch run should use first.
  "frigate_mqtt" -- subscribes to Frigate's MQTT events and uses ONLY
      detected objects, exactly as production will. Switch to this once
      your technical officer has verified Frigate reliably detects
      vehicles in the simulator's video stream (see docs/FRIGATE_INTEGRATION.md).
"""
import json
import logging
import os
import time

import requests
import paho.mqtt.client as mqtt

from max_pressure import LaneState, next_phase_recommendation, recommended_green_extension
from frigate_adapter import FrigateDetectionStore

logging.basicConfig(level=logging.INFO, format="%(asctime)s [controller] %(message)s")
log = logging.getLogger("controller")

SIM_API_URL = os.environ.get("SIM_API_URL", "http://localhost:8000")
MQTT_HOST = os.environ.get("MQTT_HOST", "localhost")
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
FRIGATE_CAMERA_NAME = os.environ.get("FRIGATE_CAMERA_NAME", "stcs_sim")
DETECTION_SOURCE = os.environ.get("DETECTION_SOURCE", "ground_truth")
DECISION_INTERVAL_S = float(os.environ.get("DECISION_INTERVAL_S", "2.0"))

detection_store = FrigateDetectionStore()


def on_mqtt_connect(client, userdata, flags, reason_code, properties=None):
    log.info("connected to MQTT broker %s:%s (rc=%s)", MQTT_HOST, MQTT_PORT, reason_code)
    client.subscribe("frigate/events")


def on_mqtt_message(client, userdata, msg):
    if msg.topic == "frigate/events":
        detection_store.handle_event(msg.payload)


def start_mqtt_client() -> mqtt.Client:
    client = mqtt.Client(client_id="stcs-controller", callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
    client.on_connect = on_mqtt_connect
    client.on_message = on_mqtt_message
    for attempt in range(30):
        try:
            client.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
            break
        except (ConnectionRefusedError, OSError) as e:
            log.warning("MQTT broker not ready yet (%s), retrying (%d/30)...", e, attempt + 1)
            time.sleep(2)
    client.loop_start()
    return client


def get_lane_states_ground_truth() -> dict[str, LaneState]:
    resp = requests.get(f"{SIM_API_URL}/state", timeout=2.0)
    resp.raise_for_status()
    data = resp.json()
    return {a: LaneState(approach=a, queue_pcu=data["lanes"][a]["queue_pcu"]) for a in ("N", "E", "S", "W")}, data


def get_lane_states_frigate() -> tuple[dict[str, LaneState], dict]:
    resp = requests.get(f"{SIM_API_URL}/state", timeout=2.0)  # still need current phase/state from the plant
    resp.raise_for_status()
    data = resp.json()
    detected = detection_store.lane_states()
    lane_states = {a: LaneState(approach=a, queue_pcu=detected[a]["queue_pcu"]) for a in ("N", "E", "S", "W")}
    return lane_states, data


def send_command(action: str, value=None):
    try:
        resp = requests.post(f"{SIM_API_URL}/command", json={"action": action, "value": value, "source": "max_pressure_controller"}, timeout=2.0)
        return resp.json()
    except requests.RequestException as e:
        log.error("failed to reach simulator API: %s", e)
        return {"accepted": False, "detail": str(e)}


def check_emergency_preemption(plant_state: dict) -> bool:
    """Returns True if an emergency-preemption command was issued this cycle.
    TDS Section 17 workflow: any approach with an emergency vehicle waiting
    (not currently having right of way) gets preemption requested immediately.
    If the previously-preempted approach no longer has one present (already
    served), preemption is cancelled rather than left to expire on its own."""
    lanes = plant_state["lanes"]
    current_preemption = plant_state.get("preemption_approach")

    for approach, lane in lanes.items():
        if lane["emergency_present"] and not lane["has_row"] and current_preemption != approach:
            result = send_command("emergency_preempt", approach)
            log.warning("EMERGENCY VEHICLE on approach %s -> preemption requested: %s", approach, result["detail"])
            return True

    if current_preemption and not lanes.get(current_preemption, {}).get("emergency_present", False):
        result = send_command("cancel_preemption")
        log.info("emergency vehicle on %s already served -> preemption cancelled: %s", current_preemption, result["detail"])
        return True

    return False


def control_loop():
    log.info("controller starting, detection_source=%s, sim_api=%s", DETECTION_SOURCE, SIM_API_URL)
    mqtt_client = None
    if DETECTION_SOURCE == "frigate_mqtt":
        mqtt_client = start_mqtt_client()

    last_group_seen = None
    while True:
        try:
            if DETECTION_SOURCE == "frigate_mqtt":
                lane_states, plant_state = get_lane_states_frigate()
            else:
                lane_states, plant_state = get_lane_states_ground_truth()

            current_group = plant_state["phase_group"]

            preempted_this_cycle = check_emergency_preemption(plant_state)
            if preempted_this_cycle:
                time.sleep(DECISION_INTERVAL_S)
                continue

            rec = next_phase_recommendation(lane_states, current_group)
            log.info(
                "phase=%s state=%s | NS=%.1f EW=%.1f | recommend=%s switch=%s",
                current_group, plant_state["state"], rec["ns_pressure"], rec["ew_pressure"],
                rec["recommended_group"], rec["should_switch"],
            )

            if rec["should_switch"]:
                result = send_command("request_switch")
                log.info("-> request_switch: %s", result["detail"])
            elif plant_state["state"] == "GREEN":
                ext = recommended_green_extension(lane_states, current_group)
                result = send_command("set_green_duration", ext)
                if result["accepted"]:
                    log.info("-> set_green_duration(%.1f): %s", ext, result["detail"])

        except requests.RequestException as e:
            log.error("simulator API unreachable, backing off: %s", e)
        except Exception:
            log.exception("unexpected error in control loop, continuing")

        time.sleep(DECISION_INTERVAL_S)


if __name__ == "__main__":
    control_loop()
